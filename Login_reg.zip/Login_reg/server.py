from flask import Flask, request, redirect, render_template, session, flash
from mysqlconnection import MySQLConnector
app = Flask(__name__)
app.secret_key ="sKey"
mysql = MySQLConnector(app,'login_reg')
import re
import os, binascii
import md5
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')

#This is where I keep my functions:
#####################################

#This function checks to see if the inputted email is already present in the database, and makes sure it has valid e-mail syntax. If it already exists or has invalid syntax, it flashes an error message. 


@app.route('/')
def index():
    return redirect('/login')
@app.route('/login')
def loginpage():
    return render_template('login.html')
@app.route('/registration')
def registration ():
    return render_template('registration.html')
@app.route('/gotoreg')
def gotoreg():
    return redirect('/registration')
@app.route('/gotolog')
def gotolog():
    return redirect('/login')

@app.route('/login', methods=['POST'])
def login():
    password=request.form['password']
    email=request.form['email']
    query = "SELECT * FROM users WHERE email = '"+email+"'"
    data = {
            'email': request.form['email'],
            }
    sPassword = mysql.query_db(query, data)[0]['password']
    salt = mysql.query_db(query, data)[0]['salt']
    if md5.new(password + salt).hexdigest() == sPassword:
        session['id'] = mysql.query_db(query, data)[0]['id']
    return redirect('/')
@app.route('/register', methods=['POST'])
def register():
    counter = 0
    print counter
    first_name=request.form['first_name']
    last_name=request.form['last_name']
    email=request.form['email']
    password=request.form['password']
    password_confirm=request.form['password_confirm']
    query = "SELECT * FROM users WHERE email = '"+email+"'"
    data = {
            'email': request.form['email'],
            }
    if len(mysql.query_db(query, data))>0:
        flash("E-mail has already been used, please use another e-mail address")
    if len(email)<1:
        flash("Please enter an e-mail address")
    else:
        if not EMAIL_REGEX.match(email):
            flash("Please enter a valid e-mail address")
        else:
            counter+=1
    print counter
#This checks to see if the length of the first name is at least two characters, and that all the characters are letters. If either is not true, it flashes an error message.
    if len(first_name)<1:
        flash("Please enter a first name")
    else:
        if len(first_name) < 2:
            flash("First name should be at least two characters")
        else:
            counter+=1
        if not first_name.isalpha():
            flash("First name should only be letters")
        else:
            counter+=1
    print counter
#This checks to see if the length of the last name is at least two characters, and that all the characters are letters. If either is not true, it flashes an error message.
    if len(last_name)<1:
        flash("Please enter a last name")
    else:
        if not last_name.isalpha():
            flash("Last name should only be letters")
        else:
            counter+=1
        if len(last_name) < 2:
            flash("Last name should be at least two characters")
        else:
            counter+=1
    print counter
#This checks to see if the password is over 8 characters and if it matches the password confirmation field.
    if len(password) <1:
        flash("Please enter a password")
    else:
        if len(password)<8 and len(password)>0:
            flash("Password must be at least 8 characters long")
        else:
            counter+=1
        if password != password_confirm:
            flash("Both password fields must match")
        else:
            counter+=1
    print counter
#This inputs user data into the database.
    if counter == 7:
        flash("You have successfully registered with the website")
        salt = binascii.b2a_hex(os.urandom(15))
        hashed_pw = md5.new(password + salt).hexdigest()
        query = "INSERT INTO users (first_name, last_name, email, password, salt) VALUES ('"+first_name+"','"+last_name+"','"+email+"','"+hashed_pw+"','"+salt+"')"
        data = {
            'first_name': first_name,
            'last_name': last_name,
            'email': email,
            'password':hashed_pw
            }
        mysql.query_db(query, data)
    return redirect('/')    
app.run(debug=True)
        

        


# @app.route('/regpage')
# def insert():
    
#     message = ''
#     email=request.form['email']
#     print email
#     query = "SELECT * FROM email WHERE email = '"+email+"'"
#     print query
#     # We'll then create a dictionary of data from the POST data received.
#     data = {
#              'email': request.form['email'],
#            }
#     # Run query, with dictionary values injected into the query.
#     print mysql.query_db(query, data)
#     if len(mysql.query_db(query, data))>0:
#         message = "email has already been used"
#         return render_template('index.html', message = message, email=email)
#     elif not EMAIL_REGEX.match(email):
#         message = "please enter a valid e-mail"
#         return render_template('index.html', message = message)
#     else:
#         query = "INSERT INTO email (email) VALUES ('"+email+"')"   
#         mysql.query_db(query, data)
#         message = ''
#         return redirect('/')